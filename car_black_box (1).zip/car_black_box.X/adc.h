/* 
 * File:   adc.h
 * Author: Nidhin s
 *
 * Created on June 25, 2023, 9:04 PM
 */
#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */