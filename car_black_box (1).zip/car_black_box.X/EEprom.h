/* 
 * File:   EEprom.h
 * Author: Nidhin
 *
 * Created on June 25, 2023, 6:36 PM
 */


#ifndef EEPROM_H
#define	EEPROM_H


#define SLAVE_WRITE_EEPROM             0xA0
#define SLAVE_READ_EEPROM              0xA1


void ext_eeprom_24C02_str_write(unsigned char addr, char *data);
unsigned char ext_eeprom_24C02_read(unsigned char addr);
void ext_eeprom_24C02_byte_write(unsigned char addr,  char data);

#endif	