/*
 * File:   timers.c
 * Author: Nidhin
 *
 * Created on June 25, 2023, 5:45 PM
 */


#include <xc.h>
#include"timers.h"
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)


void init_timer2(void)
{
    
    T2CKPS0 = 1;
    T2CKPS1 = 1;
    PR2 = 250;
    TMR2IE = 1;
    TMR2ON = 0;
}
