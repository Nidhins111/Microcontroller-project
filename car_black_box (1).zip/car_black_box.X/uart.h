/* 
 * File:   uart.h
 * Author: Nidhin
 *
 * Created on July 16, 2023, 6:40 AM
 */

#ifndef UART_H
#define	UART_H

#define FOSC                20000000

void init_uart(unsigned long baud);
unsigned char getcharx(void);
void putchars(unsigned char data);
void putsx(const char *s);


#endif	